export const GUEST_DISPLAY_NAME_REFERENCE = 'guestDisplayNames';
export const GUEST_PROVIDERS_REFERENCE = 'guestProviders';
export const HOST_PROVIDERS_REFERENCE = 'hostProviders';
